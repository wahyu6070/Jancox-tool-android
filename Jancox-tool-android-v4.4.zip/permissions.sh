chmod 755 $SYSTEM/bin/jancox
chmod 755 $SYSTEM/bin/jancoxmenu
