rm -rf /data/local/jancox-tool
rm -rf /data/adb/jancox-tool
rm -rf /data/data/com.termux/files/usr/bin/jancox
rm -rf $system/bin/jancox
rm -rf $system/bin/jancoxmenu
