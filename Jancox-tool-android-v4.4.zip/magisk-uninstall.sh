#example magisk uninstall.sh files
rm -rf /data/local/jancox-tool
rm -rf /data/adb/jancox-tool
rm -rf /data/data/com.termux/files/usr/bin/jancox
