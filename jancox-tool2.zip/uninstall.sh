rm -rRf /data/local/jancox-tool
